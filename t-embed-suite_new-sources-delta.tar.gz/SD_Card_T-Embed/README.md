# SD_Card_T-Embed/

**Copie o conteúdo desta pasta (os arquivos e subpastas, não a pasta em si)
para a raiz de um cartão microSD FAT32** e insira na placa antes de ligá-la
com o Bruce já instalado (via Launcher).

> Apesar do nome da pasta (herdado da placa alvo deste repositório), quase
> todo o conteúdo aqui é **genérico do Bruce** — funciona em qualquer placa
> rodando o firmware, não só no T-Embed CC1101. As únicas exceções são
> `themes/` e eventuais imagens de boot, que podem depender da resolução de
> tela específica de cada placa.

## Visão geral

| Subpasta | Arquivos | Conteúdo |
|---|---|---|
| [`UniversalIR/`](#universalir-e-universalrf) | 829 | Banco IR oficial do Bruce |
| [`UniversalRF/`](#universalir-e-universalrf) | 2.052 | Banco Sub-GHz oficial do Bruce (Garages/Gates/Vehicles) |
| [`BadUSB_BlueDucky/`](#badusb_blueducky) | 3 | Payloads Ducky Script oficiais |
| [`nfc/`](#nfc) | 5.344 | Tags NFC/RFID (Amiibo, Tonies, dicionários Mifare, tags de brincadeira, comunidade) |
| [`themes/`](#themes) | 96 | Temas de interface |
| [`wifi_portals/`](#wifi_portals) | 43 | Templates de captive portal (Evil Portal) |
| [`interpreter_js_apps/`](#interpreter_js_apps) | 60 | Apps/scripts para o interpretador JS do Bruce |
| [`subghz_extra_dbs/`](#subghz_extra_dbs) | 14.088 | Bancos Sub-GHz extras, por categoria |
| [`ir_extra_dbs/`](#ir_extra_dbs) | 16.813 | Bancos IR extras, por categoria |
| [`badusb_extra_payloads/`](#badusb_extra_payloads) | 3.031 | Payloads BadUSB extras |
| [`music_rtttl/`](#music_rtttl) | 11.196 | Músicas em formato RTTTL (texto `.txt`) para o player de áudio do Bruce |

Total: **53.557 arquivos**, ~1,1 GB.

---

## UniversalIR/ e UniversalRF/

Bancos de dados oficiais que acompanham a release do Bruce — 829 arquivos
IR e 2.052 arquivos RF (organizados em categorias como Garages, Gates,
Vehicles), curados e validados pelos mantenedores do projeto.

- Fonte: [BruceDevices/firmware](https://github.com/BruceDevices/firmware) (release oficial)
- Licença: AGPL-3.0

## BadUSB_BlueDucky/

Payloads Ducky Script oficiais que acompanham o Bruce (3 arquivos,
PT-BR e EN).

- Fonte: [BruceDevices/firmware](https://github.com/BruceDevices/firmware) (release oficial)
- Licença: AGPL-3.0

## nfc/

Tags NFC/RFID de múltiplas fontes, mescladas e deduplicadas por hash de
conteúdo:

| Subpasta | Conteúdo | Fonte |
|---|---|---|
| `AmiiboDB/` | Dump completo de Amiibo (`.bin`/`.nfc`) | [AmiiboDB/Amiibo](https://github.com/AmiiboDB/Amiibo) |
| `Bruce-Scripts-Heaven_RFID/` | Tags RFID da comunidade | [sloth632/Bruce-Scripts-Heaven](https://github.com/sloth632/Bruce-Scripts-Heaven) |
| `Tonies_NFC/` | 738 tags Toniebox (Paw Patrol, Pokémon, DC, National Geographic Kids, etc.), organizadas por idioma/coleção | [nortakales/flipper-zero-tonies](https://github.com/nortakales/flipper-zero-tonies) |
| `UberGuidoZ_Fun_Files/` | Tags NFC de brincadeira (RickRoll, links, easter eggs) | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |
| `UberGuidoZ_Mifare_Classic_Dict/` | Dicionários de chaves para cartões Mifare Classic | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |
| `UberGuidoZ_Amiibo_Tools/` | Conversores/ferramentas Amiibo (complementar ao AmiiboDB, não duplicado) | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |
| `UberGuidoZ_H10301_RFID_Bruteforce/` | Bruteforcer pro formato de cartão de acesso HID H10301 (Wiegand 26-bit) | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |

Total: 5.344 arquivos.

## themes/

Temas de interface para o Bruce:

- `README.md`, `Theme_Builder.html`, `example/` — material oficial do Bruce
- `Bruce-Themes_community/` — temas extras da comunidade ([anonimoKali/Bruce-Themes](https://github.com/anonimoKali/Bruce-Themes))
- `Bruce-Themes_wendells01/` — 3 temas extras ("Orange - Akkok", "Orange - Tsoucky", "Flipper inspired black theme") + animações de boot pro T-Embed e M5Stick ([wendells01/Bruce-Themes](https://github.com/wendells01/Bruce-Themes))
- `Pwnagotchi_theme_pfefferle/` — tema com estética inspirada no Pwnagotchi, com ícones próprios pros módulos do Bruce (wifi, ble, rf, ir, nfc, gps etc.); confirma compatibilidade com Cardputer, M5StickC Plus2 e CYD ([pfefferle/bruce-pwnagotchi-theme](https://github.com/pfefferle/bruce-pwnagotchi-theme))

Total: 96 arquivos. **Esta é uma das únicas pastas que pode depender da
placa específica** (resolução de tela) — confira compatibilidade antes de
aplicar um tema feito para outro hardware.

## wifi_portals/

Templates de Evil Portal / captive portal, oficiais do Bruce, em duas
línguas:

- `en/` — facebook, google, instagram, microsoft, router_update (5 páginas)
- `pt-br/` — as mesmas 5 páginas em português
- `evil portal/readme.md` — instruções de uso
- `router_login_batcherss/` — 22 templates de tela de login de roteador por marca (TP-LINK, Xiaomi, Asus, Mercusys, Keenetic, Huawei, Tenda, Mikrotik, Netis), em variantes Bruce e Marauder ([Batcherss/evil-portal-html](https://github.com/Batcherss/evil-portal-html))
- `fake_login_borys/` — 7 templates de login falso de serviços conhecidos (Apple ID, Facebook, Google, T-Mobile, etc.) ([Borys-esp/EvilPortal_DB](https://github.com/Borys-esp/EvilPortal_DB))

Total: 43 arquivos.

> **Aviso**: estes templates simulam páginas de login de serviços reais.
> Use apenas em testes de segurança autorizados ou ambientes controlados —
> nunca contra terceiros sem consentimento.

## interpreter_js_apps/

Scripts/apps para o interpretador JavaScript embutido do Bruce:

- Jogos: `Snake_Cardputer.js`, `Snake_Stick_CoreS3.js`, `dino_game.js`,
  `pingpong.js`, `space_shooter.js`, `highway_racer.js`, `tamagochi.js`
- Utilitários: `calculator_t-embed.js`, `crypto-prices.js`, `dtmf.js`,
  `ir2keys.js`, `spectrum_t-embed.js`, `timer_background.js`
- Brute-forcers: `ir_brute.js`, `rf_brute.js`, `wifi_brute.js`
- `gifs/` + `gifs.js` — suporte a GIFs na interface
- `BruceScripts_community/` — extras da comunidade ([badgib/BruceScripts](https://github.com/badgib/BruceScripts))
- `js-apps-bruce/` — extras da comunidade ([michauMiau/js-apps-bruce](https://github.com/michauMiau/js-apps-bruce))
- `ProtoPirate.js` — decodificador multi-protocolo de chaveiro/controle de carro ([Senape3000/ProtoPirate-Bruce](https://github.com/Senape3000/ProtoPirate-Bruce))
- `App_Store.js` — launcher/loja de apps dentro do próprio interpretador JS ([Jiggyv3/Bruce-App-Store](https://github.com/Jiggyv3/Bruce-App-Store))
- `rename-catch.js` — utilitário de renomear/organizar arquivos ([Jiggyv3/Bruce-App-Store](https://github.com/Jiggyv3/Bruce-App-Store))
- `rf_433_replay.js` — replay de sinais Sub-GHz 433MHz ([Jiggyv3/Bruce-App-Store](https://github.com/Jiggyv3/Bruce-App-Store))
- `ir_brute_force.js`, `rf_brute_nmrf.js` — implementações alternativas de bruteforce IR/Sub-GHz, mesma função de `ir_brute.js`/`rf_brute.js` (oficiais) mas código próprio ([Jiggyv3/Bruce-App-Store](https://github.com/Jiggyv3/Bruce-App-Store))
- `browser_OnChainTemplars.js`, `cryptocurrencies_OnChainTemplars.js` — implementações alternativas de navegador web e cotação de criptomoedas, mesma função de `crypto-prices.js` já incluído (não há navegador oficial equivalente) ([OnChainTemplars/bruce-apps](https://github.com/OnChainTemplars/bruce-apps), GPL-3.0)

Total: 60 arquivos.

> **Nota**: o `Bruce-App-Store` (Jiggyv3) também tinha um `rf_jammer.js`
> (ferramenta de jamming ativo de RF, com aviso legal embutido no próprio
> código dizendo que é ilegal na maioria das jurisdições) que **foi
> deixado de fora** — jamming é uma categoria de risco diferente dos
> bancos de replay/clonagem e bruteforce já presentes aqui (que leem/testam
> sinais, não interferem ativamente neles). Essa é a única exclusão
> deliberada nesta pasta; todo o resto do que foi encontrado e é
> tecnicamente compatível com o Bruce está incluído, mesmo quando duplica
> a função de algo que já existe.

## subghz_extra_dbs/

Bancos Sub-GHz **além** do `UniversalRF/` oficial, reorganizados por
**categoria** (device/uso), mesclando todas as fontes numa única árvore e
deduplicando por hash de conteúdo. A proveniência por arquivo individual se
perde na fusão — as fontes agregadas estão listadas abaixo.

Fontes agregadas nesta pasta:

| Fonte | Repositório |
|---|---|
| Coleção "flagship" da comunidade Flipper Zero (Sub-GHz + BadUSB + NFC + Music) | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |
| Coleção geral de sinais | [Zero-Sploit/FlipperZero-Subghz-DB](https://github.com/Zero-Sploit/FlipperZero-Subghz-DB) |
| Sinais RF da comunidade Bruce | [sloth632/Bruce-Scripts-Heaven](https://github.com/sloth632/Bruce-Scripts-Heaven) |
| Botões de campainha/customer service comercial | [DRA6N/SubGhz_Cust_Serv](https://github.com/DRA6N/SubGhz_Cust_Serv) |
| Sinal de abertura da tampa de carregamento Tesla | [Robbbbbbbbb/tesla-chargeport](https://github.com/Robbbbbbbbb/tesla-chargeport) |
| Pulseiras de LED de evento (protocolo CrowdLED, EN+ES) | [niltefa/Flipper-CrowdLED-Wristbands](https://github.com/niltefa/Flipper-CrowdLED-Wristbands) |

Categorias notáveis: `Garages`, `Gates`, `Vehicles`, `Doorbells`,
`Ceiling_Fans`, `Concert bracelet` (com subpasta `CrowdLED_Wristbands/`),
`Smart_Home_Remotes`, `Retekess pager system t119`, entre ~65 outras.
Algumas categorias têm nomes duplicados com grafias diferentes
(`Ceiling Fans` vs `Ceiling_Fans`) porque vieram de fontes distintas que
nomeavam a mesma coisa de forma diferente — a fusão preserva ambas em vez
de adivinhar qual renomear.

Total: 14.088 arquivos únicos (após deduplicação — ver
[Deduplicação](#deduplicação-aplicada)).

## ir_extra_dbs/

Bancos IR **além** do `UniversalIR/` oficial, reorganizados por
**categoria** (device/uso) da mesma forma que o Sub-GHz.

Fontes agregadas nesta pasta:

| Fonte | Repositório |
|---|---|
| Principal banco IR da comunidade Flipper Zero (TVs, ACs, consoles etc.) | [Lucaslhm/Flipper-IRDB](https://github.com/Lucaslhm/Flipper-IRDB) |
| IR extra da comunidade Bruce | [sloth632/Bruce-Scripts-Heaven](https://github.com/sloth632/Bruce-Scripts-Heaven) |
| Banco IR **oficial** do time do Flipper Zero (mesclado dentro das categorias já existentes, em `<Categoria>/flipperdevices_IRDB/`) | [flipperdevices/IRDB](https://github.com/flipperdevices/IRDB) |
| IR extra independente (pasta `_sasiplavnik_extra/`) | [sasiplavnik/Flipper-IRDB](https://github.com/sasiplavnik/Flipper-IRDB) |
| Controle de vaporizador Arizer XQ2 (pasta `_magikh0e_extra/`) | [magikh0e/FlipperZero_Stuff](https://github.com/magikh0e/FlipperZero_Stuff) |

Categorias notáveis: `TVs`, `ACs`, `Consoles`, `Projectors`, `Cable_Boxes`,
`Box_SetTopBoxes` (nova — set-top boxes majoritariamente de marcas
chinesas/asiáticas: Xiaomi, ZTE, XGIMI, EVPAD, etc., trazida pelo
flipperdevices/IRDB), `Brand_(sorted)` (a mesma coleção organizada por
marca em vez de tipo de dispositivo), entre ~50 outras.

Total: 16.813 arquivos únicos (após deduplicação). Só os arquivos `.ir` do
flipperdevices/IRDB foram trazidos — os `.json`/`.png` de metadado que
acompanham cada dispositivo são específicos da UI do app oficial do
Flipper e não são lidos pelo Bruce.

## badusb_extra_payloads/

Payloads BadUSB **além** do `BadUSB_BlueDucky/` oficial:

| Subpasta | Conteúdo | Fonte |
|---|---|---|
| `Flipper-Zero-BadUSB/` | Payloads da comunidade Flipper Zero | [I-Am-Jakoby/Flipper-Zero-BadUSB](https://github.com/I-Am-Jakoby/Flipper-Zero-BadUSB) |
| `BadUsb-Library/` | Biblioteca organizada por técnica (MITRE ATT&CK) | [Starvinci/BadUsb-Library](https://github.com/Starvinci/BadUsb-Library) |
| `Bruce-Scripts-Heaven_BAD/` | Payloads Ducky Script (Windows/macOS/Linux/Android/iOS) | [sloth632/Bruce-Scripts-Heaven](https://github.com/sloth632/Bruce-Scripts-Heaven) |
| `UberGuidoZ_BadUSB/` | Payloads adicionais (bombs, pranks, recon, exfiltração) não duplicados nas fontes acima | [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) |

Total: 3.031 arquivos únicos (após deduplicação e remoção de 3 arquivos
"prank" de ~15MB cada, que eram hexdumps de imagem sem função real).

> Wordlists de bruteforce (rockyou.txt, openwall.txt etc.) **não estão
> incluídas** neste repositório — são padrão da indústria de segurança e
> fáceis de obter separadamente se você precisar do módulo de bruteforce
> WiFi do Bruce.

## music_rtttl/

Coleção de músicas em formato **RTTTL** (Ring Tone Text Transfer
Language), salvas como arquivos de texto `.txt` — sim, texto mesmo, é o
formato que o player de áudio/buzzer do Bruce lê e toca diretamente no
T-Embed (ou qualquer placa com buzzer/speaker suportado).

Organizada em subpastas alfabéticas (`A/` a `Z/`, mais `0/` e `#/` para
nomes que começam com número/símbolo) e duas categorias extras:
`Arcade/` (temas de jogos NES/PC/arcade) e `NES/`, `PC/` dentro dela.

- Fonte: [UberGuidoZ/Flipper](https://github.com/UberGuidoZ/Flipper) (pastas `Music_Player/RTTTL_DUMP`, `Original_Files`, `Arcade_Tones`, `Theme_Songs`, `flipnoise`)
- Licença: GPL-3.0

Total: 11.196 arquivos únicos (após deduplicação interna entre as
subpastas de origem — 264 duplicatas removidas).

---

## Deduplicação aplicada

Os bancos extras (Sub-GHz, IR, BadUSB, NFC) vinham com sobreposição entre
fontes (vários projetos redistribuindo o mesmo conteúdo). Foi feita
deduplicação por **hash de conteúdo** (não apenas nome de arquivo) em cada
merge:

| Categoria | Observação |
|---|---|
| Sub-GHz | Dedup pesado nas fontes originais (33.723 → ~14.071), mais dedup incremental ao mesclar CrowdLED (22 duplicatas evitadas) |
| IR | Dedup pesado nas fontes originais (30.139 → ~12.825), mais 2.116 duplicatas evitadas ao mesclar o flipperdevices/IRDB (muito dele já cobria os mesmos códigos genéricos/reaproveitados entre marcas) e 572 ao mesclar o sasiplavnik/Flipper-IRDB |
| BadUSB | 316 duplicatas evitadas ao mesclar `UberGuidoZ_BadUSB/` contra o que já existia |
| NFC | 111 duplicatas evitadas ao mesclar `Tonies_NFC/` contra o que já existia |
| Music RTTTL | 264 duplicatas internas evitadas entre as 5 subpastas de origem do UberGuidoZ |
| Temas / Portais / Apps JS | Comparados por hash contra a árvore inteira — 0 duplicatas encontradas nessas fontes (conteúdo genuinamente novo) |

Dois forks idênticos do mesmo dataset (`techniixdotcom/Bruce-Scripts` e
`0xN0WHERE/BRUCE-FILES`) foram descartados inteiramente por serem cópias
exatas de `sloth632/Bruce-Scripts-Heaven`.

## O que foi considerado e descartado

Alguns itens de nicho pesquisados numa rodada de curadoria **não foram
incluídos** por não se aplicarem a este setup — a maioria porque são
aplicativos compilados especificamente para o firmware/hardware do
**Flipper Zero real** (não o Bruce/ESP32) e não rodam neste dispositivo:

| Item | Motivo |
|---|---|
| T119 Bruteforcer (Retekess pager, `xb8/t119bruteforcer`) | Já estava presente — os mesmos 3 arquivos `.sub` já vieram por outra fonte agregada aqui |
| XRemote (app avançado de IR) | App `.fap` compilado pro firmware/hardware do Flipper Zero, não roda no Bruce/ESP32 |
| Sentry Safe plugin | App `.fap` compilado pro Flipper Zero (usa GPIO específico do hardware STM32 dele) |
| GPS reader (`ezod/flipperzero-gps`) | App `.fap` compilado pro Flipper Zero (`application.fam` = manifesto de app do firmware oficial deles) |
| COM Port Scanner Emulator | Mesma categoria — funcionalidade de emulação USB-HID específica do firmware Flipper Zero |
| Wav_Player (arquivos `.wav` reais, ~2.4GB) | Peso inviável para um repositório GitHub, e boa parte é música com copyright (trilhas reais de artistas) — o `music_rtttl/` cobre o mesmo caso de uso em formato leve e sem essas questões |
| `rf_jammer.js` (do Jiggyv3/Bruce-App-Store) | Ferramenta de jamming ativo de RF — diferente do resto do conteúdo aqui porque a interferência se propaga pro ambiente (afeta qualquer receptor na frequência, não só um alvo específico), e o próprio código traz aviso de que é ilegal operar isso na maioria das jurisdições. |
| `Information Stealer.txt`, `Disable Firewall and Create An Admin Account.txt` (do magikh0e/FlipperZero_Stuff, pasta `BadUSB/`) | Payloads que o próprio autor rotula como "Backdoor" — criam conta de admin oculta e desativam o firewall num Windows alvo sem consentimento. Categoria de conteúdo malicioso, diferente dos payloads ofensivos de segurança/pentest já presentes em `badusb_extra_payloads/` — não incluídos |
| `probonopd/irdb` | Banco de IR grande e ativo, mas em formato `.csv` próprio, não `.ir` — precisaria de conversão pra ser utilizável pelo Bruce/Flipper; fora de escopo por ora |
| Forks idênticos de bancos de IR já incluídos (`sosbgit/Flipper-Zero-IRDB`, `logickworkshop/Flipper-IRDB`, `mahan518/Flipper_IR_Database`, `heytem/Flipper-Zero-IR-DataBase`, `RandomDebugError/irdb`) | Cópias/forks confirmados de fontes já presentes, sem conteúdo próprio — reconferido por hash, zero arquivos novos |
| `Jalapenothedragon/evil-portal-html` | Mesmo conjunto de templates (por marca de roteador) que `Batcherss/evil-portal-html` já incluído, com 2 variantes a menos — reconferido por hash, zero arquivos novos |
| `MuddledBox/FlipperZeroSub-GHz`, `ErikLentz/Flipper-Finds` | Reconferidos por hash a pedido: só metadado de repositório (LICENSE/README) e uma foto (.jpg) eram "novos" — nenhum arquivo de conteúdo real (`.sub`/`.ir`/`.nfc`) que já não estivesse aqui |

`ir_brute_force.js`/`rf_brute_nmrf.js` (Jiggyv3) e `cryptocurrencies.js`/
`browser.js` (OnChainTemplars) foram reconsiderados e **incluídos** — ver
[interpreter_js_apps/](#interpreter_js_apps) acima; são reimplementações
próprias, não duplicatas de fato, e não têm problema de segurança.
`magikh0e/FlipperZero_Stuff` também teve um arquivo `.ir` legítimo
incluído (controle de vaporizador Arizer XQ2) — ver
[ir_extra_dbs/](#ir_extra_dbs). Os 2 payloads BadUSB "Backdoor" do mesmo
autor não entraram — ver a tabela acima.

## Aviso de uso

Vários bancos aqui (Sub-GHz de veículos/portões de terceiros, payloads
BadUSB, templates de captive portal, bruteforcers de RFID) são ferramentas
de segurança ofensiva/pesquisa em RF. O uso é de responsabilidade de quem
opera o dispositivo — verifique a legislação local antes de usar fora de
um ambiente controlado ou autorizado.
